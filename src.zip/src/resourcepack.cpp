#include "starspeed/resourcepack.hpp"
#include "motor/content/resourcelocation.hpp"

Motor::Mod* resourcePackMod = fallbackMod;
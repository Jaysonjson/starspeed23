#pragma once
#include "motor/registry/mod.hpp"

extern Motor::Mod* resourcePackMod;

namespace StarSpeed {
	/*void installResourcePack(std::string zipPath) {

	}*/
}
#include "starspeed/discord.hpp"
Fuchs::Discord::Discord discordApi{};
Motor::GameObject* discordAvatar = new Motor::GameObject();
Motor::Texture* avatarTexture = nullptr;
#pragma once
#include "vector"
#include "string"

namespace StarSpeed {
    extern std::vector<std::string> SPLASHS;
}
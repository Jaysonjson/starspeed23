#pragma once

namespace StarSpeed {
    void switchToTitleScreen();
}
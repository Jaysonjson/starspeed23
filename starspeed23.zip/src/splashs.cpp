#include "starspeed/splashs.hpp"
namespace StarSpeed {
    std::vector<std::string> SPLASHS = {
        "Here could be COLOR{\"color\":[144,0,0,255],\"text\":\" your \"}COLOR splash text!",
        "Also try StarSpeed18!",
        "Alot of Cows were harmed for this Game",
        "Is this the place to post Ban Appeals?",
        "Can you sign my TARDIS?",
        "1.12.2",
        "Star COLOR{\"color\":[4,144,4,255],\"text\":\"Weed\"}COLOR !",
        "Is this the Dalek Mod?",
        "Theres a bee inside me",
        "Toppings in Burgers are COLOR{\"color\":[144,0,0,255],\"text\":\" MIDDLINGS \"}COLOR !"
    };
}
/* Jayson Hartmann */
#pragma once

#include <fuchslib/shorter.hpp>
#include <sdl/SDL.h>

namespace Motor::SPR {
	/*constexpr int colorTest = 0xFF27D0;
	constexpr int colorTest2 = 0x2F27F0;
	uint32 logo[16 * 16] = {
			colorTest2, colorTest2, colorTest2, colorTest2, colorTest2, colorTest2, colorTest2, colorTest2,
			colorTest2, colorTest2, colorTest2, colorTest2, colorTest2, colorTest2, colorTest2, colorTest2,
			colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest,
			colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest,
			colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest,
			colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest,
			colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest,
			colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest,
			colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest,
			colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest,
			colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest,
			colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest,
			colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest,
			colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest,
			colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest,
			colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest,
			colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest,
			colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest,
			colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest,
			colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest,
			colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest,
			colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest,
			colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest,
			colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest,
			colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest,
			colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest,
			colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest,
			colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest,
			colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest,
			colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest,
			colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest,
			colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest
	};

	uint32 logo8[8 * 8] = {
		colorTest2, colorTest2, colorTest2, colorTest2, colorTest2, colorTest2, colorTest2,
		colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest,
		colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest,
		colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest,
		colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest,
		colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest,
		colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest,
		colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest,
		colorTest, colorTest, colorTest, colorTest, colorTest, colorTest, colorTest
	};

	SDL_Surface* create(void* spr, int size) {
		return SDL_CreateRGBSurfaceFrom(spr, size, size, 32, size * 2, 0xFF0000, 0x00FF00, 0x0000FF, 0x000000);
	}*/
}

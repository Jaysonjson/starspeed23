/* Jayson Hartmann  27/03/2022 */
#pragma once

#include "motor/interfaces/component.hpp"
#include "motor/content/texture.hpp"
#include "motor/components/transform.hpp"
#include "motor/motor.hpp"

namespace Motor {

	/* Sprite Component
	* Used to render Sprites
	*/
	class SpriteComponent : public IComponent {
	protected:
		Texture* texture_ = nullptr;

	public:
		bool ignoreCamera_ = false;
		//bool ui_ = false;
		bool translatePosition_ = true;
		bool translateScale_ = true;
		SDL_Rect destRectangle_{};
		TransformComponent* transform_ = nullptr;
		Motor::Event<std::function<void(bool&)>, bool&> preRenderEvent{};
		SDL_BlendMode blendMode_ = SDL_BLENDMODE_NONE;
		SDL_Point center_{};
		SDL_RendererFlip flip_ = SDL_RendererFlip::SDL_FLIP_NONE;
		Vector2D translate_{ 0, 0 };
		Color32 customColor_{ 0, 0, 0, 0 };
		bool useCustomColor_ = false;
		bool translateExtraPostion_ = true;
		Scale customScale_{};
		bool useCustomScale_ = false;
		float customAngle_ = 500;
		bool loadAtInit_ = true;

	protected:
		SpriteComponent() = default;

	public:
		/* Textures should never be owned by a Component, better create a list with textures, this is just for quick testing */
		explicit SpriteComponent(const string& path) : texture_(new Texture{ path }) {};
		explicit SpriteComponent(ResourceLocation path) : texture_(new Texture{ path }) {};
		explicit SpriteComponent(const string& path, uint32 pixelFormat) : texture_(new Texture{ path, pixelFormat }) {};
		/* Use This */
		explicit SpriteComponent(Texture* texture) : texture_(texture) {};

		//explicit SpriteComponent(const string& path, bool loadAtInit) : texture_(new Texture{ path }), loadAtInit_(loadAtInit) {};
		//explicit SpriteComponent(ResourceLocation path, bool loadAtInit) : texture_(new Texture{ path }), loadAtInit_(loadAtInit) {};
		//explicit SpriteComponent(const string& path, uint32 pixelFormat, bool loadAtInit) : texture_(new Texture{ path, pixelFormat }), loadAtInit_(loadAtInit) {};
		/* Use This */
		//explicit SpriteComponent(Texture* texture, bool loadAtInit) : texture_(texture), loadAtInit_(loadAtInit) {};

	public:

		void createRuid() override {
			ruid_ = Fuchs::generateRUID("COMP", "SPR", { 8, 4, 15 });
		}

		void setTexture(Texture* texture) {
			this->texture_ = texture;
		}

		Texture* getTexture() {
			return this->texture_;
		}

		void changeTexture(const string& path, bool unload = false) {
			if (this->texture_ && unload) this->texture_->unload();
			this->texture_ = new Texture{ path };
			this->texture_->load();
		}

		void init() override {
			IComponent::init();
			if(loadAtInit_) texture_->safeLoad();
			transform_ = owner_->getComponent<TransformComponent>();
			if (!transform_) owner_->addComponent<TransformComponent>();
			transform_ = owner_->getComponent<TransformComponent>();
		}

		void update(TransformComponent* transform) {
			if (transform) {
				Vector2D pos = Vector2D{ transform->position };
				pos += translate_;
				Vector2D screenPos = translatePosition_ ? pos.screen() : pos;
				Scale adjustedScale = translateScale_ ? transform->scale.cameraAdjusted() : transform->scale;
				if (useCustomScale_) {
					adjustedScale = translateScale_ ? customScale_.cameraAdjusted() : customScale_;
				}
				if (ignoreCamera_) {
					screenPos = pos.fixedScreen();
					if (getriebe.getGame()->getCurrentScene()->getCamera().target != transform) {
						adjustedScale.x /= getriebe.getGame()->getCurrentScene()->getCamera().zoom;
						adjustedScale.y /= getriebe.getGame()->getCurrentScene()->getCamera().zoom;
					}
				}

				destRectangle_.x = ((screenPos.getX() - (adjustedScale.x / 2)));
				destRectangle_.y = ((screenPos.getY() - (adjustedScale.y / 2)));
				destRectangle_.w = adjustedScale.x;
				destRectangle_.h = adjustedScale.y;

				TransformComponent* cameraTarget = getriebe.getGame()->getCurrentScene()->getCamera().getTarget();
				if (cameraTarget) {
					if (cameraTarget == transform) {
						destRectangle_.x += getriebe.getGame()->getCurrentScene()->getCamera().position.getX();
						destRectangle_.y += getriebe.getGame()->getCurrentScene()->getCamera().position.getY();
					}
				}
			}
		}

		void update() override {
			update(transform_);
		};

		void render(TransformComponent* transform) {
			if (texture_ && texture_->get()) {
				bool shouldRender = true;
				preRenderEvent.dispatch(shouldRender);
				if (!shouldRender) return;
				float angle = 0;
				if (transform) {
					if (!transform->onScreen) return;
					SDL_SetTextureColorMod(texture_->get(), transform->color.getRed(), transform->color.getGreen(), transform->color.getBlue());
					SDL_SetTextureAlphaMod(texture_->get(), transform->color.getAlpha());
					angle = transform->rotation.getAngle();
				}
				if (customAngle_ != 500) {
					angle = customAngle_;
				}
				if (useCustomColor_) {
					SDL_SetTextureColorMod(texture_->get(), customColor_.getRed(), customColor_.getGreen(), customColor_.getBlue());
					SDL_SetTextureAlphaMod(texture_->get(), customColor_.getAlpha());
				}

				SDL_SetTextureBlendMode(texture_->get(), blendMode_);
				SDL_RenderCopyEx(getriebe.sdl_renderer(), texture_->get(), NULL, &destRectangle_, angle, &center_, flip_);
				SDL_SetTextureColorMod(texture_->get(), 255, 255, 255);
				SDL_SetTextureAlphaMod(texture_->get(), 255);
				SDL_SetTextureBlendMode(texture_->get(), SDL_BLENDMODE_NONE);
			}
		}

		void render() override {
			render(transform_);
		}

		constexpr bool onlySingleInstance() { return false; }
	};

	class DynamicSpriteComponent : public SpriteComponent {
	public:
		explicit DynamicSpriteComponent(const string& path) : SpriteComponent(path) {};
		explicit DynamicSpriteComponent(const string& path, uint32 pixelFormat) : SpriteComponent(path, pixelFormat) {};
		explicit DynamicSpriteComponent(DynamicTexture* texture) { texture_ = texture; };
		explicit DynamicSpriteComponent(ResourceLocation path) { texture_ = new DynamicTexture(path); };


		//explicit DynamicSpriteComponent(const string& path, bool loadAtInit) : SpriteComponent(path, loadAtInit) {};
		//explicit DynamicSpriteComponent(const string& path, uint32 pixelFormat, bool loadAtInit) : SpriteComponent(path, pixelFormat, loadAtInit) {};
		//explicit DynamicSpriteComponent(DynamicTexture* texture, bool loadAtInit) { texture_ = texture; loadAtInit_ = loadAtInit; };
		//explicit DynamicSpriteComponent(ResourceLocation path, bool loadAtInit) { texture_ = new DynamicTexture(path); loadAtInit_ = loadAtInit; };

	public:
		void init() override {
			SpriteComponent::init();
			DynamicTexture* dynTexture = dynamic_cast<DynamicTexture*>(texture_);
			if (dynTexture) {
				if (dynTexture->getHolders().empty() && !dynTexture->exists()) dynTexture->load();
				dynTexture->getHolders().emplace_back(this->ruid_);
			}
		}

		void onObjectDestroy() override {
			DynamicTexture* dynTexture = dynamic_cast<DynamicTexture*>(texture_);
			if (dynTexture) {
				std::erase_if(dynTexture->getHolders(), [this](Fuchs::RUID& objRuid) { return objRuid == this->ruid_; });
				dynTexture->validate();
			}
		}

		void onRemove() override {
			onObjectDestroy();
		}
	};
}

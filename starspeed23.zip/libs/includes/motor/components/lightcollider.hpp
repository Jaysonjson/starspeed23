/* Jayson Hartmann  13/05/2022 */
#pragma once

#include "motor/interfaces/component.hpp"
#include "motor/content/texture.hpp"
#include "motor/components/transform.hpp"
#include "motor/motor.hpp"

namespace Motor {
	class LightColliderComponent : public IComponent {

	};
}
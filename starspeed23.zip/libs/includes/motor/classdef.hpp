/* Jayson Hartmann */
#pragma once

namespace Motor {
    class GameObject;
}

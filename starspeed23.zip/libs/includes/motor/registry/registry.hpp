#pragma once
#include "vector"
#include "fuchslib/key.hpp"
#include "registryobject.hpp"
#include "mod.hpp"
namespace Motor {

    template <typename T>
    class Registry {
        std::vector<RegistryObject<T>*> objects_{};
        Mod* mod_;
    public:

        Registry(Mod* mod): mod_(mod) {}

        void registerExternObject(T* t, Fuchs::FuchsKey key) {
            RegistryObject<T>* reg = new RegistryObject{t, key};
            objects_.push_back(reg);
        }

        void registerObject(T* t, string key) {
            RegistryObject<T>* reg = new RegistryObject{t, Fuchs::FuchsKey{key, mod_->getId()}};
            objects_.push_back(reg);
        }

        bool exists(const Fuchs::FuchsKey& key) {
            for (const auto& item: getObjects()) {
                KeyAble* keyAble = item;
                if(keyAble) {
                    if(keyAble->getKey().asString() == key.asString()) {
                        return true;
                    }
                }
            }
            return false;
        }

        std::vector<RegistryObject<T>*> getObjects() {
            return objects_;
        }
    };
}
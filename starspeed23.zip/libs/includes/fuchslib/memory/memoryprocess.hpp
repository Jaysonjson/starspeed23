#pragma once

#include "fuchsmemory.hpp"

#ifdef _WIN32
#include "windows.h"
#include "TlHelp32.h"
#include "atlstr.h"
#include "string"

class MemoryProcess {
	FUCHS_HANDLE handle_ = nullptr;
	FUCHS_PID id_ = 0;
	std::string exe_ = "";
public:

	MemoryProcess(std::string procName): exe_(procName) {}
	~MemoryProcess() {
		Close();
	}

public:

	bool Attach();

	FUCHS_HANDLE Handle() {
		return this->handle_;
	}

	FUCHS_PID ID() {
		return this->id_;
	}

	/* Close the Handle */
	void Close() {
		CloseHandle(Handle());
	}

	/* Kill the Process */
	void Terminate(UINT exitCode = 1) {
		TerminateProcess(Handle(), exitCode);
		Close();
	}

	FUCHS_WORD GetModuleBaseAddress(TCHAR* lpszModuleName);
};
#endif
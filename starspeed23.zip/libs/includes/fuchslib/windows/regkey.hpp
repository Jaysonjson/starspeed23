/* Jayson */
#pragma once
#include "../shorter.hpp"
#ifdef WINDOWS
#include "../utility.hpp"
#include <windows.h>
#include <winreg.h>

namespace Fuchs::WIN {


    class RegHKey {
        HKEY key_;
        HKEY original_;
        const std::string subKey_;

    public:
        RegHKey(HKEY key, std::string subKey) : original_(key), subKey_(std::move(subKey)) {}

    public:
        std::string getSubKey() const { return subKey_; }
        HKEY getHKey() const { return key_; }
        HKEY getOriginal() const { return original_; }

        LONG create() {
            DWORD pos;
            LONG result = RegCreateKeyEx(original_, subKey_.c_str(), 0, NULL, REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL, &key_, &pos);
            close();
            return result;
        }

        void close() {
            RegCloseKey(key_);
        }

        LONG open(DWORD access = KEY_ALL_ACCESS) {
            return RegOpenKeyEx(
                original_,
                subKey_.c_str(),
                0,
                access,
                &key_
            );
        }

    };

    /*
     * https://docs.microsoft.com/en-us/windows/win32/sysinfo/registry-key-security-and-access-rights
     * https://docs.microsoft.com/en-us/windows/win32/api/winreg/nf-winreg-reggetvaluea?redirectedfrom=MSDN
     * */
    template <typename T, DWORD type, DWORD typeRestriction>
    class RegKey {
    protected:
        const std::string value_;
        T t_;
        DWORD size_;
        RegHKey* key_;

    public:
        RegKey(RegHKey* key, std::string value) : key_(key), value_(std::move(value)), size_(sizeof(T)) {}
        virtual ~RegKey() = default;
    public:
        DWORD getSize() const { return size_; }
        std::string getValue() const { return value_; }
        RegHKey* getHKey() const { return key_; }

        virtual LONG refresh() {
            return RegGetValue(key_->getOriginal(), key_->getSubKey().c_str(), value_.c_str(), typeRestriction, nullptr, &t_, &size_);
        }

        T get() const { return t_; }

        virtual LONG set(T t, DWORD access = KEY_ALL_ACCESS) {
            key_->open(access);
            LONG result = RegSetValueEx(
                key_->getHKey(),
                value_.c_str(),
                0,
                type,
                ((BYTE*)(&t)),
                size_);
            key_->close();
            return result;
        }
    };

    class StringRegKey : public RegKey<std::string, REG_SZ, RRF_RT_ANY> {
    public:
        StringRegKey(RegHKey* key, std::string value) : RegKey(key, value) {}

    public:
        LONG set(std::string t, DWORD access = KEY_ALL_ACCESS) override {
            key_->open(access);
            LONG result = RegSetValueEx(
                key_->getHKey(),
                value_.c_str(),
                0,
                REG_SZ,
                (LPBYTE)(t.c_str()),
                (t.size() + 1) * sizeof(wchar_t));
            key_->close();
            return result;
        }

        LONG refresh() override {
            DWORD len = 1024;
            DWORD readDataLen = len;
            PWCHAR readBuffer = (PWCHAR)malloc(sizeof(PWCHAR) * len);
            if (readBuffer == NULL) return -1;
            LONG Ret = key_->open();
            if (Ret == ERROR_SUCCESS) {
                Ret = RegQueryValueEx(key_->getHKey(), value_.c_str(), NULL, NULL, (BYTE*)readBuffer, &readDataLen);
                while (Ret == ERROR_MORE_DATA) {
                    len += 1024;
                    readBuffer = (PWCHAR)realloc(readBuffer, len);
                    readDataLen = len;
                    Ret = RegQueryValueEx(key_->getHKey(), value_.c_str(), NULL, NULL, (BYTE*)readBuffer, &readDataLen);
                }
                t_ = Fuchs::Utility::wStringToString(std::wstring{ readBuffer });
                free(readBuffer);
            }
            key_->close();
            return Ret; 
        }

        LONG refresh2() {
            DWORD dataSize{};
            key_->open();
            //LONG retCode = RegGetValue(key_->getHKey(), key_->getSubKey().c_str(), value_.c_str(), RRF_RT_REG_SZ, nullptr, nullptr, &dataSize);
            LONG retCode = RegGetValue(key_->getHKey(), key_->getSubKey().c_str(), value_.c_str(), RRF_RT_REG_SZ, nullptr, nullptr, &dataSize);
            if (retCode != ERROR_SUCCESS) return retCode;
            std::wstring data;
            data.resize(dataSize / sizeof(wchar_t));
            retCode = RegGetValue(key_->getHKey(), key_->getSubKey().c_str(), value_.c_str(), RRF_RT_REG_SZ, nullptr, &data[0], &dataSize);
            if (retCode != ERROR_SUCCESS) return retCode;
            DWORD stringLengthInWchars = dataSize / sizeof(wchar_t);
            stringLengthInWchars--;
            data.resize(stringLengthInWchars);
            t_ = std::string(data.begin(), data.end());
            std::wcout << data << std::endl;
            std::cout << std::string(data.begin(), data.end()) << std::endl;
            key_->close();
            return retCode;
        }
    };

    using DWORD_RegKey = RegKey<DWORD, REG_DWORD, RRF_RT_DWORD>;
    using STRING_RegKey = StringRegKey;
};
#endif
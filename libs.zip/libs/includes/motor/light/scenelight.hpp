/* Jayson Hartmann */
#include <visibility/visibility.hpp>

namespace Motor {
	class SceneLight {

	public:
		std::vector<geometry::line_segment<geometry::vec2>> getSegments() {
			return {};
		}
	};
}
#pragma once
#include "string"

namespace Motor {
	class Ling {
	public:
		std::string literal() {
			return "";
		}

		std::string translateable() {
			return "";
		}

	};
}
/* Jayson Hartmann */
#pragma once

namespace Motor {
	/* Objects which are not influenced by the camera (UI) should be here */
	class Canvas {

	};
}
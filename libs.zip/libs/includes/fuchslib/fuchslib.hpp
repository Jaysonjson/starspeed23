#pragma once
#include "osplatform.hpp"

namespace Fuchs {
    extern OSPlatform osPlatform;
}
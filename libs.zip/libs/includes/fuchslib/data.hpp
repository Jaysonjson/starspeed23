/* Jayson */
#pragma once

#include "shorter.hpp"

namespace Fuchs::Data {

    enum LINUX_DESKTOP_ENVIRONMENT {
        UNKNOWN, PLASMA, GNOME, MATE, LXDE, JWM, XFCE4 
    };

   /* template <int32 conversion, typename T>
    struct Unit {
    };

    using Byte = Unit<1, Byte>;
    using KiloByte = Unit<1024, Byte>;
    using MegaByte = Unit<104857, KiloByte>;*/

}
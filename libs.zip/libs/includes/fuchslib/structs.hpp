/* Jayson Hartmann */
#pragma once

#include "shorter.hpp"

/*
 * Basically a range.
 * Holds 2 variables: T max and T min
 */
dtp
struct m_range {
    T max = 0;
    T min = 0;
};
